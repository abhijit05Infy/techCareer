export { YoutubePlayerModule } from './ng2-youtube-player.module';
export { YoutubePlayerComponent } from './youtube-player.component';

export {
  IPlayerApiScriptOptions, IPlayerOutputs, IPlayerSize
} from './models';
