import { Component } from '@angular/core';
@Component({
  templateUrl:'./partnerships.html'
})
export class PartnershipsComponent { }
